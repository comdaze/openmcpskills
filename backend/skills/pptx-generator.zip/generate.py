"""
PowerPoint 生成脚本 - 在 AWS Bedrock Code Interpreter 沙箱中执行
"""
import json
import sys
from pptx import Presentation
from pptx.util import Inches, Pt

def create_presentation(data):
    """创建 PowerPoint 演示文稿"""
    prs = Presentation()
    prs.slide_width = Inches(10)
    prs.slide_height = Inches(7.5)
    
    title_text = data.get('title', '未命名演示')
    slides_data = data.get('slides', [])
    
    for slide_info in slides_data:
        layout_type = slide_info.get('layout', 'content')
        
        if layout_type == 'title':
            slide = prs.slides.add_slide(prs.slide_layouts[0])
            slide.shapes.title.text = slide_info.get('title', '')
            if len(slide.placeholders) > 1:
                slide.placeholders[1].text = slide_info.get('content', '')
        else:
            slide = prs.slides.add_slide(prs.slide_layouts[1])
            slide.shapes.title.text = slide_info.get('title', '')
            content = slide_info.get('content', '')
            if len(slide.shapes) > 1:
                text_frame = slide.shapes[1].text_frame
                text_frame.text = content
    
    filename = f"{title_text.replace(' ', '_')}.pptx"
    prs.save(filename)
    print(f"✅ 成功生成 PowerPoint: {filename}")
    print(f"📊 共 {len(slides_data)} 张幻灯片")
    return filename

if __name__ == "__main__":
    # 从标准输入读取参数
    input_data = json.loads(sys.stdin.read())
    create_presentation(input_data)
