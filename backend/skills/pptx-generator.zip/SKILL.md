---
name: pptx-generator
description: 在沙箱中生成 PowerPoint 演示文稿
execution:
  type: code_interpreter
  runtime: python
  entrypoint: generate.py
  timeout: 120
  network: sandbox
---

# PowerPoint 生成器

根据用户提供的内容和结构，在安全沙箱中生成 PowerPoint 演示文稿。

## 参数

- `title` (string, required): 演示文稿标题
- `slides` (array, required): 幻灯片内容数组
  - `title` (string): 幻灯片标题
  - `content` (string): 幻灯片内容
  - `layout` (string): 布局类型 (title, content, two_column)

## 示例

```json
{
  "title": "我的演示",
  "slides": [
    {
      "title": "欢迎",
      "content": "这是第一页",
      "layout": "title"
    },
    {
      "title": "主要内容",
      "content": "- 要点1\n- 要点2\n- 要点3",
      "layout": "content"
    }
  ]
}
```
